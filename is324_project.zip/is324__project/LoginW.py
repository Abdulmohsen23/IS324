from tkinter import *
from tkinter import ttk, messagebox
from PIL import ImageTk  # pip3 install pillow
import re

from models.user import User


def validate_student_id(value):
    if len(value) == 11:
        return False
    if value.isdigit():
        # print(input_value)
        return True
    elif value == "":
        # print(input_value)
        return True
    else:
        # print(input_value)
        return False


class LoginW:
    def __init__(self):
        self.root = Tk()
        self.root.title("Login Page")  # For Title of the page
        self.root.geometry("1350x700+0+0")  # Resolution of the page , top, bottom
        self.root.config(bg="white")

        self.current_user = User()

        # ===BackGround Image===
        self.bg = ImageTk.PhotoImage(file="images/back.png")
        Label(self.root, image=self.bg).place(x=0, y=0, relwidth=1, relheight=1)
        # ===Side Image===
        # self.left = ImageTk.PhotoImage(file="images/side.jpg")
        # Label(self.root, image=self.left).place(x=250, y=250, width=230, height=230)

        # ===Login Frame===
        frame1 = Frame(self.root, bg="white")
        frame1.place(x=480, y=85, width=700, height=550)

        # ====Footer Frame=====
        footer = Frame(self.root, bg="gray")
        footer.place(x=0, y=610, relwidth=1, relheight=30)

        Label(footer, text="King Saud University", font=("comic sans ms", 25, "bold"), bg="gray", fg="#ECF0F1").place(x=400, y=12)

        Label(frame1, text="Login Here", font=("times new roman", 20, "bold"), bg="white", fg="green").place(x=270, y=30)

        val_com_stu_id = (self.root.register(validate_student_id), '%P')

        # --------1st Raw
        Label(frame1, text="Student ID No", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=100)
        self.txt_student_id = Entry(frame1, width=25, font=("times new roman", 15), bg="lightgray", validate="key", validatecommand=val_com_stu_id)# validate="key", validatecommand=val_com_stu_id
        self.txt_student_id.place(x=220, y=100, width=250)

        # ---------Password
        Label(frame1, text="Password", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=140)
        self.txt_password = Entry(frame1, show="*", font=("times new roman", 15), bg="lightgray")
        self.txt_password.place(x=220, y=140, width=250)

        # -------Role
        Label(frame1, text="Role", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=180)
        self.cmb_role = ttk.Combobox(frame1, font=("times new roman", 13), state='readonly', justify=CENTER)
        self.cmb_role['values'] = ("Student", "Admin")
        self.cmb_role.place(x=220, y=180, width=250)
        self.cmb_role.current(0)

        # Login Button with Image
        img_ref = ImageTk.PhotoImage(file="images/login.png")
        self.btn_img = img_ref
        Button(frame1, image=self.btn_img, bd=0, cursor="hand2", command=self.signin_data).place(x=50, y=240) # "hand2"

        # -------Signup Button-----
        Button(self.root, text="Sign Up", command=self.go_signup, font=("times new roman", 20), bd=0, cursor="hand2").place(x=320, y=520)
        self.root.mainloop()

    def go_signup(self):
        self.root.update()
        self.root.destroy()
        import SignupW
        SignupW.SignupW()

    def go_admin(self, admin):
        self.root.update()
        self.root.destroy()
        import AdminW
        AdminW.AdminW(admin)

    def go_student(self, student):
        self.root.update()
        self.root.destroy()
        import StudentW
        StudentW.StudentW(student)

    def clear_data(self):
        self.txt_student_id.delete(0, END)
        self.txt_password.delete(0, END)

    def signin_data(self):

        if self.txt_student_id.get() == "" or self.txt_password.get() == "":
            messagebox.showerror("Error !", "All Fields are Required !", parent=self.root)
        elif len(self.txt_student_id.get()) != 10:
            messagebox.showerror("Error !", "Student ID should be 10 digits", parent=self.root)
        else:
            try:
                self.current_user.set_user(self.cmb_role.get(), self.txt_student_id.get(), self.txt_password.get(),
                                              '', '', '', '')

                my_data = self.current_user.check_user_in_db(True)

                if my_data:

                    messagebox.showinfo("Success !", "Login Successfully !", parent=self.root)
                    self.clear_data()

                    if self.cmb_role.get() == 'Student':
                        self.go_student(my_data[0])
                    else:
                        self.go_admin(my_data[0])

                else:

                    # Error label because username is already on DB
                    messagebox.showerror("Error !", "SOMETHING WENT WRONG!\n Please, introduce your credentials again.",
                                         parent=self.root)
            except Exception as es:
                messagebox.showerror("Error", f"Error due to : {str(es)}", parent=self.root)


# root = Tk()
# obj = LoginW()
# root.mainloop()
