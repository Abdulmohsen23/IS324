import mysql.connector as mysql


class Book:
    want_exit_popup_anymore = False

    def __init__(self):
        self.id = None
        self.title = None
        self.no_copies = 0
        self.shelf_no = 0

    def set_book(self, BookId , title, no_copies, shelf_no):
        self.id = BookId
        self.title = title
        self.no_copies = no_copies
        self.shelf_no = shelf_no

    def check_book_in_db(self):
        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()

        query_to_db = f"""
        SELECT * FROM books WHERE title = '{self.title}' AND shelf_no = '{self.shelf_no}'
        """

        cursor.execute(query_to_db)
        rows = cursor.fetchall()

        con.close()

        return rows

    def new_book(self):
        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()

        table_name = 'books'
        cursor.execute("insert into " + table_name + " (title, no_copies, shelf_no) values('"
                       + self.title + "', '" + self.no_copies + "', '" + self.shelf_no + "')")

        con.commit()
        self.id = cursor.lastrowid
        con.close()

    def fetch_book(self, student_id):
        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()

        query_to_db = f"""
        SELECT * FROM books where no_copies > 0 and id not in (select book_id from reservations where student_id = {str(student_id)})
        """

        cursor.execute(query_to_db)
        rows = cursor.fetchall()

        con.close()

        return rows

    def fetch_book_borrow(self):
        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()

        query_to_db = f"""
        SELECT b.*, s.firstname, s.lastname, s.id as student_id FROM `books` b, `students` s where s.id in (select student_id from reservations)
        """

        cursor.execute(query_to_db)
        rows = cursor.fetchall()

        con.close()

        return rows

    def book_return(self, book_id, student_id):
        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()

        cursor.execute("delete from reservations where book_id = " + str(book_id) + " and student_id = " + str(student_id))
        con.commit()

        cursor.execute("update books set no_copies = no_copies + 1 where id = " + str(self.book_id))
        con.commit()

        con.close()

        return True
