import mysql.connector as mysql
from datetime import datetime


class Reservation:
    want_exit_popup_anymore = False

    def __init__(self):

        self.id = None
        self.book_id = None
        self.student_id = None
        self.borrow_start = None
        self.borrow_end = None

    def set_reservation(self, book_id, student_id, borrow_start, borrow_end):
        self.student_id = student_id
        self.book_id = book_id
        self.borrow_start = borrow_start
        self.borrow_end = borrow_end

    def check_reservation_in_db(self):
        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()

        t = datetime.strptime(self.borrow_start.split(" at ")[0], '%m/%d/%y')
        start = t.strftime('%Y-%m-%d %H:%M:%S')
        t = datetime.strptime(self.borrow_end.split(" at ")[0], '%m/%d/%y')
        end = t.strftime('%Y-%m-%d %H:%M:%S')

        query_to_db = f"""
        SELECT * FROM reservations WHERE borrow_start = '{start}' AND borrow_end = '{end}'
        """

        cursor.execute(query_to_db)
        rows = cursor.fetchall()

        con.close()

        return rows

    def new_reservation(self):
        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()

        t = datetime.strptime(self.borrow_start.split(" at ")[0], '%m/%d/%y')
        start = t.strftime('%Y-%m-%d %H:%M:%S')
        t = datetime.strptime(self.borrow_end.split(" at ")[0], '%m/%d/%y')
        end = t.strftime('%Y-%m-%d %H:%M:%S')

        table_name = 'reservations'
        cursor.execute("insert into " + table_name + " (book_id, student_id, borrow_start, borrow_end) values("
                       + str(self.book_id) + ", " + str(self.student_id) + ", '" + start + "', '" + end + "')")

        con.commit()
        self.id = cursor.lastrowid

        cursor.execute("update books set no_copies = no_copies - 1 where id = " + str(self.book_id))
        con.commit()

        con.close()

    def fetch_my_reservation(self, student_id):
        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()

        query_to_db = f"""
        SELECT c.*, r.borrow_start, r.borrow_end FROM books c
        INNER JOIN reservations r
        on c.id = r.book_id
        WHERE r.student_id = {student_id}
        """

        cursor.execute(query_to_db)
        rows = cursor.fetchall()

        con.close()

        return rows

