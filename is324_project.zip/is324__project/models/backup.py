import csv
import mysql.connector as mysql


class Backup:
    want_exit_popup_anymore = False

    def __init__(self):
        print('')

    def export_all(self):

        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()

        query_to_db = f"""
        SELECT * FROM admins
        """

        cursor.execute(query_to_db)
        rows = cursor.fetchall()

        file = open("backup_admin.csv", 'w', newline='', encoding='utf-8')
        csvwriter = csv.writer(file)
        for x in rows:
            csvwriter.writerow(x)
        file.close()

        query_to_db = f"""
        SELECT * FROM students
        """

        cursor.execute(query_to_db)
        rows = cursor.fetchall()

        file = open("backup_student.csv", 'w', newline='', encoding='utf-8')
        csvwriter = csv.writer(file)
        for x in rows:
            csvwriter.writerow(x)
        file.close()

        query_to_db = f"""
        SELECT * FROM books
        """

        cursor.execute(query_to_db)
        rows = cursor.fetchall()

        file = open("backup_book.csv", 'w', newline='', encoding='utf-8')
        csvwriter = csv.writer(file)
        for x in rows:
            csvwriter.writerow(x)
        file.close()

        con.close()

        return True
