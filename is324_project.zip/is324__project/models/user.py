import hashlib
import mysql.connector as mysql


class User:
    want_exit_popup_anymore = False

    def __init__(self):

        self.id = None
        self.role = None
        self.user_id = None
        self.password = None
        self.firstname = None
        self.lastname = None
        self.email = None
        self.phone = None

    def is_logged(self):

        if self.user_id is not None:
            return True

    def set_user(self, role, user_id, password, firstname, lastname, email, phone):

        self.role = role
        self.user_id = user_id
        self.password = password
        self.firstname = firstname
        self.lastname = lastname
        self.email = email
        self.phone = phone

    def check_user_in_db(self, reg=False):

        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()
        query_to_db = f"""
                SELECT * FROM {'students' if self.role == 'Student' else 'admins'} WHERE user_id = '{self.user_id}'
                """
        cursor.execute(query_to_db)
        rows = cursor.fetchall()

        # if len(rows) > 0:
        #     password_hashed = hashlib.sha256(self.password.encode()).hexdigest()
        #     query_to_db += f" AND password = '{password_hashed}'"

        # cursor.execute(query_to_db)
        #data = cursor.fetchall()

        con.close()

        return rows

    def new_user(self):

        con = mysql.connect(host="feqra.com", user="feqracom_d_ksu_book", password="P@ssw0rD_123", database="feqracom_d_ksu_book")
        cursor = con.cursor()

        password_hashed = hashlib.sha256(self.password.encode()).hexdigest()
        table_name = 'students' if self.role == 'Student' else 'admins'
        cursor.execute("insert into " + table_name + " (firstname, lastname, user_id, email, phone, password) values('"
                       + self.firstname + "', '" + self.lastname + "', '" + self.user_id + "', '" + self.email + "', '"
                       + self.phone + "', '" + password_hashed + "')")
        # cursor.execute("commit")
        con.commit()
        self.id = cursor.lastrowid
        con.close()
