from datetime import datetime
from tkinter import *
from tkinter import ttk, messagebox
from tkinter.ttk import Treeview

from GUICalendar import GUICalendar
from models.book import Book
from models.reservation import Reservation


class StudentW:
    def __init__(self, logged_in_user):
        self.logged_in_user = logged_in_user
        self.root = Tk()
        self.root.title("Student")
        self.root.geometry("1350x900+0+0")
        self.root.config(bg="gray")

        self.current_book = Book()
        self.current_reservation = Reservation()

        # ===Login Frame===
        frame1 = Frame(self.root, bg="white")
        frame1.place(x=10, y=50, width=1330, height=750)

        # ====Footer Frame=====
        footer = Frame(self.root, bg="gray")
        footer.place(x=0, y=810, relwidth=1, relheight=30)

        Label(footer, text="King Saud University", font=("comic sans ms", 25, "bold"), bg="gray", fg="#ECF0F1")\
            .place(x=400, y=12)

        Label(frame1, text="Student", font=("times new roman", 20, "bold"), bg="white", fg="green").place(x=270, y=30)

        Button(self.root, text="Logout", command=self.logout, font=("times new roman", 20), bd=0, cursor="hand2")\
            .place(x=1242, y=1)

        tab_control = ttk.Notebook(frame1)
        tab_control.place(x=10, y=50, width=1330, height=720)

        tab1 = Frame(tab_control)
        tab2 = Frame(tab_control)

        tab_control.add(tab1, text='Borrow a Book')
        tab_control.add(tab2, text='My Books')
        tab_control.pack(expand=1, fill="both")

        columns = ('id', 'title', 'no_copies', 'shelf_no')
        self.tv_book = Treeview(tab1, columns=columns, show='headings', height=8)
        self.tv_book.grid(column=0, row=0, padx=30, pady=30)
        self.tv_book.heading('id', text='ID')
        self.tv_book.column('id', anchor=CENTER, stretch=NO, width=200)
        self.tv_book.heading('title', text='Title')
        self.tv_book.column('title', anchor=CENTER, stretch=NO, width=350)
        self.tv_book.heading('no_copies', text='Number of Copies')
        self.tv_book.column('no_copies', anchor=CENTER, stretch=NO, width=350)
        self.tv_book.heading('shelf_no', text='Shelf Number')
        self.tv_book.column('shelf_no', anchor=CENTER, stretch=NO, width=350)
        self.tv_book.bind("<Double-1>", self.on_treeview_double_clicked)

        my_data = self.current_book.fetch_book(self.logged_in_user[0])

        count = 0
        for row in my_data:
            self.tv_book.insert(parent='', index=count, text='', values=(row[0], row[1], row[2], row[3]))
            count += 1

        # --------1st Raw
        Label(tab1, text="Book ID", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=220)
        self.txt_book_id = Entry(tab1, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_book_id.place(x=220, y=220, width=250)

        # --------2nd Raw
        Label(tab1, text="Book Title", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=260)
        self.txt_book_title = Entry(tab1, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_book_title.place(x=220, y=260, width=250)

        # --------3rd Raw
        Label(tab1, text="Number of copies", font=("times new roman", 15, "bold"), bg="white", fg="gray")\
            .place(x=50, y=300)
        self.txt_book_no_copies = Entry(tab1, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_book_no_copies.place(x=220, y=300, width=250)

        # --------4th Raw
        Label(tab1, text="Shelf Number", font=("times new roman", 15, "bold"), bg="white", fg="gray")\
            .place(x=50, y=340)
        self.txt_book_shelf_no = Entry(tab1, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_book_shelf_no.place(x=220, y=340, width=250)

        # --------5th Raw
        Label(tab1, text="Borrow Start", font=("times new roman", 15, "bold"), bg="white", fg="gray")\
            .place(x=50, y=380)
        self.txt_borrow_start = Entry(tab1, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_borrow_start.place(x=220, y=380, width=250)

        # --------6th Raw
        Label(tab1, text="Borrow End", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=420)
        self.txt_borrow_end = Entry(tab1, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_borrow_end.place(x=220, y=420, width=250)

        Button(tab1, text="Book", command=self.borrow, font=("times new roman", 20), bd=0, cursor="hand2")\
            .place(x=50, y=470)

        Button(tab2, text="Show", command=self.reservation_fetch, font=("times new roman", 20), bd=0, cursor="hand2")\
            .place(x=50, y=360)
        columns = ('id', 'title', 'no_copies', 'shelf_no', 'borrow_start', 'borrow_end')
        self.tv_my_reservation = Treeview(tab2, columns=columns, show='headings', height=8)
        self.tv_my_reservation.grid(column=0, row=0, padx=30, pady=30)
        self.tv_my_reservation.heading('id', text='ID')
        self.tv_my_reservation.column('id', anchor=CENTER, stretch=NO, width=100)
        self.tv_my_reservation.heading('title', text='Book Title')
        self.tv_my_reservation.column("title", anchor=CENTER, stretch=NO, width=150)
        self.tv_my_reservation.heading('no_copies', text='Number of copies')
        self.tv_my_reservation.column('no_copies', anchor=CENTER, stretch=NO, width=150)
        self.tv_my_reservation.heading('shelf_no', text='Shelf Number')
        self.tv_my_reservation.column("shelf_no", anchor=CENTER, stretch=NO, width=150)
        self.tv_my_reservation.heading('borrow_start', text='Borrow Start')
        self.tv_my_reservation.column("borrow_start", anchor=CENTER, stretch=NO, width=150)
        self.tv_my_reservation.heading('borrow_end', text='Borrow End')
        self.tv_my_reservation.column("borrow_end", anchor=CENTER, stretch=NO, width=150)

        self.cal = GUICalendar(tab1, self.txt_borrow_start, self.txt_borrow_end)
        self.cal.place(x=220, y=390, width=250)

        self.root.mainloop()

    def borrow(self):
        if self.txt_book_title.get() == "" or self.txt_book_no_copies.get() == "" or self.txt_book_shelf_no.get() == ""\
                or self.txt_borrow_start.get() == "" or self.txt_borrow_end.get() == "":
            messagebox.showerror("Error !", "All Fields are Required !", parent=self.root)
        else:
            try:
                self.current_reservation.set_reservation(self.txt_book_id.get(), self.logged_in_user[0],
                                                         self.txt_borrow_start.get(), self.txt_borrow_end.get())

                my_data = self.current_reservation.check_reservation_in_db()

                if not my_data:
                    # Checking if student are sure about entries data...
                    response = messagebox.askokcancel("Reservation", "\nAre you sure?")
                    if response:
                        self.current_reservation.new_reservation()
                        messagebox.showinfo("Success !", "Booking Completed !", parent=self.root)
                        f = open("transactions.log", "w")

                        # datetime object containing current date and time
                        now = datetime.now()
                        # dd/mm/YY H:M:S
                        dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
                        f.write('DateTime: ' + dt_string + '; StudentID: ' + str(self.logged_in_user[0])
                                + '; Book title: ' + self.txt_book_title.get() + '; Number of copies: '
                                + self.txt_book_no_copies.get() + '; Borrow Start: ' + self.txt_borrow_start.get()
                                + '; Borrow End: ' + self.txt_borrow_end.get() + '\n')
                        # self.clear_data()
                else:  # If data != []
                    # Error label because username is already on DB
                    messagebox.showerror("Error !", "Already booked ! Try with another one.", parent=self.root)
            except Exception as es:
                messagebox.showerror("Error", f"Error due to : {str(es)}", parent=self.root)

    def reservation_fetch(self):
        my_data = self.current_reservation.fetch_my_reservation(self.logged_in_user[0])

        count = 0
        for row in my_data:
            self.tv_my_reservation.insert(parent='', index=count, text='',
                                          values=(row[0], row[1], row[2], row[3], row[4], row[5]))
            count += 1

    def on_treeview_double_clicked(self, event):
        item_details = self.tv_book.item(self.tv_book.focus()).get("values")
        self.txt_book_id.delete(0, END)
        self.txt_book_id.insert(0, item_details[0])
        self.txt_book_title.delete(0, END)
        self.txt_book_title.insert(0, item_details[1])
        self.txt_book_no_copies.delete(0, END)
        self.txt_book_no_copies.insert(0, item_details[2])
        self.txt_book_shelf_no.delete(0, END)
        self.txt_book_shelf_no.insert(0, item_details[3])

    def logout(self):
        self.root.update()
        self.root.destroy()
        import LoginW
        LoginW.LoginW()
