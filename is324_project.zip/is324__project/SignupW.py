from tkinter import *
from tkinter import ttk, messagebox
from PIL import ImageTk  # pip3 install pillow
import re

from models.user import User


def validate_student_id(input_value):
    if len(input_value) == 11:
        return False
    if input_value.isdigit():
        # print(input_value)
        return True
    elif input_value == "":
        # print(input_value)
        return True
    else:
        # print(input_value)
        return False


def validate_password(password):
    reg = "^(?=.*[A-Z].*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[@$!%*#?&])[A-Za-z0-9@$!#%*?&]{6,8}$"
    pat = re.compile(reg)
    x = re.search(pat, password)
    if x:
        return True
    else:
        return False


def check_email(email):
    reg = "^([a-zA-Z0-9\._-]+)(@ksu\.edu\.sa)$"
    pat = re.compile(reg)
    x = re.search(pat, email)
    if x:
        return True
    else:
        return False


def validate_phone(phone):
    reg = "^(05)[0-9]{8}$"
    pat = re.compile(reg)
    x = re.search(pat, phone)
    if x:
        return True
    else:
        return False


class SignupW:
    def __init__(self):
        self.root = root
        self.root.title("Registration Page")  # For Title of the page
        self.root.geometry("1350x700+0+0")  # Resolution of the page , top, bottom
        self.root.config(bg="white")

        self.current_student = User()

        # ===BackGround Image===
        self.bg = ImageTk.PhotoImage(file="images/back.png")
        Label(self.root, image=self.bg).place(x=0, y=0, relwidth=1, relheight=1)
        # ===Side Image===
        # self.left = ImageTk.PhotoImage(file="images/side.jpg")
        # Label(self.root, image=self.left).place(x=250, y=250, width=230, height=230)

        # ===Register Frame===
        frame1 = Frame(self.root, bg="white")
        frame1.place(x=480, y=85, width=700, height=550)

        # ====Footer Frame=====
        footer = Frame(self.root, bg="gray")
        footer.place(x=0, y=610, relwidth=1, relheight=30)

        Label(footer, text="King Saud University", font=("comic sans ms", 25, "bold"), bg="gray", fg="#ECF0F1").place(
            x=400, y=12)

        Label(frame1, text="Register Here", font=("times new roman", 20, "bold"), bg="white", fg="green").place(x=270,
                                                                                                                y=30)

        # --------First Row
        Label(frame1, text="First Name", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=100)
        self.txt_first_name = Entry(frame1, font=("times new roman", 15), bg="lightgray")
        self.txt_first_name.place(x=220, y=100, width=250)

        # --------Second Raw
        Label(frame1, text="Last Name", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=140)
        self.txt_last_name = Entry(frame1, font=("times new roman", 15), bg="lightgray")
        self.txt_last_name.place(x=220, y=140, width=250)

        val_com_stu_id = (self.root.register(validate_student_id), '%P')

        # --------3rd Raw
        Label(frame1, text="ID No", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50,
                                                                                                               y=180)
        self.txt_student_id = Entry(frame1, width=25, font=("times new roman", 15), bg="lightgray", validate="key",
                                    validatecommand=val_com_stu_id)
        self.txt_student_id.place(x=220, y=180, width=250)

        # ---------Password
        Label(frame1, text="Password", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=220)
        self.txt_password = Entry(frame1, show="*", font=("times new roman", 15), bg="lightgray")
        self.txt_password.place(x=220, y=220, width=250)

        # --------Confirm Password
        Label(frame1, text="Confirm Password", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50,
                                                                                                                  y=260)
        self.txt_confirm_password = Entry(frame1, show="*", font=("times new roman", 15), bg="lightgray")
        self.txt_confirm_password.place(x=220, y=260, width=250)

        # -------Email
        Label(frame1, text="Email", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=300)
        self.txt_email = Entry(frame1, font=("times new roman", 15), bg="lightgray")
        self.txt_email.place(x=220, y=300, width=250)

        # -------Contact
        Label(frame1, text="Phone No", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=340)
        self.txt_phone = Entry(frame1, font=("times new roman", 15), bg="lightgray")
        self.txt_phone.place(x=220, y=340, width=250)

        # -------Role
        Label(frame1, text="Role", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=380)
        self.cmb_role = ttk.Combobox(frame1, font=("times new roman", 13), state='readonly', justify=CENTER)
        self.cmb_role['values'] = ("Student", "Admin")
        self.cmb_role.place(x=220, y=380, width=250)
        self.cmb_role.current(0)

        # --------Terms
        # self.var_chk = IntVar()
        # Checkbutton(frame1, text="I Agree the Terms & Conditions ", variable=self.var_chk, onvalue=1, offvalue=0, bg="white", font=("times new roman", 12)).place(x=50, y=420)

        # Register Button with Image
        img_ref = ImageTk.PhotoImage(file="images/register.jpg")
        self.btn_img = img_ref
        Button(frame1, image=self.btn_img, bd=0, cursor="hand2", command=self.register_data).place(x=50, y=460)

        # -------Sign in Button-----
        Button(self.root, text="Sign In", command=self.go_login, font=("times new roman", 20), bd=0,
               cursor="hand2").place(x=320, y=520)

    def go_login(self):
        self.root.update()
        self.root.destroy()
        import LoginW
        LoginW.LoginW()

    def clear_data(self):
        self.txt_first_name.delete(0, END)
        self.txt_last_name.delete(0, END)
        self.txt_student_id.delete(0, END)
        self.txt_phone.delete(0, END)
        self.txt_email.delete(0, END)
        self.cmb_role.current(0)
        self.txt_password.delete(0, END)
        self.txt_confirm_password.delete(0, END)

    def validation(self):
        special_ch = ['~', '`', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '_', '+', '=', '{', '}', '[',
                      ']', '|', '\\', '/', ':', ';', '"', "'", '<', '>', ',', '.',
                      '?']

        msg = ""
        if len(self) == 0:
            msg = 'Password can\'t be empty'
        else:
            try:
                if not any(ch in special_ch for ch in self):
                    msg = 'At least 1 special character required!'
                elif not any(ch.isupper() for ch in self):
                    msg = 'At least 1 uppercase character required!'
                elif not any(ch.islower() for ch in self):
                    msg = 'At least 1 lowercase character required!'
                elif not any(ch.isdigit() for ch in self):
                    msg = 'At least 1 number required!'
                elif len(self) < 8:
                    msg = 'Password must be minimum of 8 characters!'
                else:
                    return True
            except Exception as ep:
                messagebox.showerror('error', ep)
        messagebox.showinfo('message', msg)
        return False

    def register_data(self):
        if self.txt_first_name.get() == "" or self.txt_last_name.get() == "" or self.txt_student_id.get() == "" \
                or self.txt_phone.get() == "" or self.txt_email.get() == "" \
                or self.txt_password.get() == "" or self.txt_confirm_password.get() == "":
            messagebox.showerror("Error !", "All Fields are Required !", parent=self.root)
        elif len(self.txt_student_id.get()) != 10:
            messagebox.showerror("Error !", "Student ID should be 10 digits", parent=self.root)
        elif self.txt_password.get() != self.txt_confirm_password.get():
            messagebox.showerror("Error !", "Password Didn't Match !", parent=self.root)
        # elif self.var_chk.get() == 0:
        #     messagebox.showerror("Error !", "Please Agree our Terms & Conditions", parent=self.root)
        elif validate_password(self.txt_password.get()) is not True:
            messagebox.showerror("Error !", "Password should have lowercase & uppercase & number & special character "
                                            "& at least two uppercase's & at least one lowercase & at"
                                            "least one number & length between 6 and 8", parent=self.root)
        elif check_email(self.txt_email.get()) is not True:
            messagebox.showerror("Error !", "Email is invalid, it should be XXX@ksu.edu.sa", parent=self.root)
        elif validate_phone(self.txt_phone.get()) is not True:
            messagebox.showerror("Error !", "Phone is invalid, it should be 05XXXXXXXX", parent=self.root)
        else:
            try:
                self.current_student.set_user(self.cmb_role.get(), self.txt_student_id.get(), self.txt_password.get(),
                                              self.txt_first_name.get(), self.txt_last_name.get(), self.txt_email.get(),
                                              self.txt_phone.get())

                my_data = self.current_student.check_user_in_db()

                if not my_data:

                    # Checking if student are sure about entries data...
                    response = messagebox.askokcancel("Student credentials", "This will be your credentials. \nAre "
                                                                             "you sure?")

                    if response:

                        self.current_student.new_user()

                        messagebox.showinfo("Success !", "Registration Completed !", parent=self.root)
                        self.clear_data()

                    else:

                        # Aborting registration
                        self.clear_data()

                else:  # If data != []

                    # Error label because username is already on DB
                    messagebox.showerror("Error !", "Already Exists id user ! Try with another one.", parent=self.root)
            except Exception as es:
                messagebox.showerror("Error", f"Error due to : {str(es)}", parent=self.root)


root = Tk()
obj = SignupW()
root.mainloop()
