from datetime import datetime
from tkinter import *
from tkinter import ttk, messagebox
from tkinter.ttk import Treeview
from tkinter import messagebox

from models.backup import Backup
from models.book import Book


def validate_book_shelf_no(input_value):
    if len(input_value) < 3:
        if input_value.isdigit():
            return True
        elif input_value == "":
            return True
        else:
            return False
    return False


class AdminW:
    def __init__(self, logged_in_user):
        self.logged_in_user = logged_in_user
        self.root = Tk()
        self.root.title("Admin")
        self.root.geometry("1350x700+0+0")
        self.root.config(bg="yellow")

        self.current_book = Book()
        self.current_backup = Backup()

        # ===Login Frame===
        frame1 = Frame(self.root, bg="white")
        frame1.place(x=10, y=50, width=1330, height=550)

        # ====Footer Frame=====
        footer = Frame(self.root, bg="gray")
        footer.place(x=0, y=610, relwidth=1, relheight=30)

        Label(footer, text="King Saud University", font=("comic sans ms", 25, "bold"), bg="gray", fg="#ECF0F1").place(
            x=400, y=12)

        Label(frame1, text="Admin", font=("times new roman", 20, "bold"), bg="white", fg="green").place(x=270, y=30)

        Button(self.root, text="Backup", command=self.backup, font=("times new roman", 20), bd=0, cursor="hand2").place(
            x=10, y=1)
        Button(self.root, text="Logout", command=self.logout, font=("times new roman", 20), bd=0, cursor="hand2").place(
            x=1242, y=1)

        tab_control = ttk.Notebook(frame1)
        tab_control.place(x=10, y=50, width=1330, height=720)

        tab1 = Frame(tab_control)
        tab2 = Frame(tab_control)

        tab_control.add(tab1, text='New Book')
        tab_control.add(tab2, text='Check Out & Return')
        tab_control.pack(expand=1, fill="both")

        # columns = ('id', 'title', 'no_copies', 'shelf_no', 'firstname', 'lastname', 'student_id')
        # self.tv_book = Treeview(tab2, columns=columns, show='headings', height=8)
        # self.tv_book.grid(column=0, row=0, padx=30, pady=30)
        # self.tv_book.heading('id', text='ID')
        # self.tv_book.column('id', anchor=CENTER, stretch=NO, width=100)
        # self.tv_book.heading('title', text='Title')
        # self.tv_book.column('title', anchor=CENTER, stretch=NO, width=150)
        # self.tv_book.heading('no_copies', text='Number of Copies')
        # self.tv_book.column('no_copies', anchor=CENTER, stretch=NO, width=150)
        # self.tv_book.heading('shelf_no', text='Shelf Number')
        # self.tv_book.column('shelf_no', anchor=CENTER, stretch=NO, width=150)
        # self.tv_book.heading('firstname', text='Firstname')
        # self.tv_book.column('firstname', anchor=CENTER, stretch=NO, width=150)
        # self.tv_book.heading('lastname', text='Last Name')
        # self.tv_book.column('lastname', anchor=CENTER, stretch=NO, width=150)
        # self.tv_book.heading('student_id', text='ID')
        # self.tv_book.column('student_id', anchor=CENTER, stretch=NO, width=0)
        # self.tv_book.bind("<Double-1>", self.on_treeview_double_clicked)

        # my_data = self.current_book.fetch_book_borrow()

        # count = 0
        # for row in my_data:
        #     self.tv_book.insert(parent='', index=count, text='',
        #                         values=(row[0], row[1], row[2], row[3], row[4], row[5], row[6]))
        #     count += 1

        # --------1st Raw
        Label(tab2, text="Book ID", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=220)
        self.txt_book_ID = Entry(tab2, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_book_ID.place(x=220, y=220, width=250)

        # --------2nd Raw
        Label(tab2, text="User ID", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=260)
        self.txt_student_id = Entry(tab2, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_student_id.place(x=220, y=260, width=250)

        Button(tab2, text="Return", command=self.book_return, font=("times new roman", 20), bd=0, cursor="hand2") \
            .place(x=50, y=470)
       
        Button(tab2, text="Checkout", command=self.book_check_out, font=("times new roman", 20), bd=0, cursor="hand2") \
            .place(x=400, y=470)
        # --------1st Raw
        Label(tab1, text="Book ID", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=60)
        self.txt_book_id = Entry(tab1, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_book_id.place(x=220, y=60, width=250)

        Label(tab1, text="Title", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=100)
        self.txt_book_title = Entry(tab1, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_book_title.place(x=220, y=100, width=250)

        Label(tab1, text="No Copies", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=140)
        self.txt_book_no_copies = Entry(tab1, width=25, font=("times new roman", 15), bg="lightgray")
        self.txt_book_no_copies.place(x=220, y=140, width=250)

        val_book_shelf_no = (self.root.register(validate_book_shelf_no), '%P')

        Label(tab1, text="Shelf No", font=("times new roman", 15, "bold"), bg="white", fg="gray").place(x=50, y=180)
        self.txt_book_shelf_no = Entry(tab1, width=25, font=("times new roman", 15), bg="lightgray", validate="key",
                                       validatecommand=val_book_shelf_no)
        self.txt_book_shelf_no.place(x=220, y=180, width=250)

        # -------Create Button-----
        Button(tab1, text="Create", command=self.book_create, font=("times new roman", 20), bd=0,
               cursor="hand2").place(x=50, y=280)

        self.root.mainloop()

    # def on_treeview_double_clicked(self, event):
    #     item_details = self.tv_book.item(self.tv_book.focus()).get("values")
    #     self.txt_book_id.delete(0, END)
    #     self.txt_book_id.insert(0, item_details[0])
    #     self.txt_student_id.delete(0, END)
    #     self.txt_student_id.insert(0, item_details[6])

    def logout(self):
        self.root.update()
        self.root.destroy()
        import LoginW
        LoginW.LoginW()

    def backup(self):
        result = self.current_backup.export_all()
        if result:
            messagebox.showinfo("Success !", "Backup Completed successfully !", parent=self.root)

    def clear_data(self):
        self.txt_book_title.delete(0, END)
        self.txt_book_no_copies.delete(0, END)
        self.txt_book_shelf_no.delete(0, END)
        self.txt_book_id.delete(0, END)

    def book_return(self):
        if self.txt_book_ID.get() == "" or self.txt_student_id.get() == "":
            messagebox.showerror("Error !", "All Fields are Required !", parent=self.root)
        else:
            try:
                response = messagebox.askokcancel("Return", "\nAre you sure?")
                if response:
                    self.current_book.book_return(self.txt_book_id.get(), self.txt_student_id.get())
                    messagebox.showinfo("Success !", "Done successfully !", parent=self.root)
            except Exception as es:
                messagebox.showerror("Error", f"Error due to : {str(es)}", parent=self.root)

    def book_check_out(self):
        if self.txt_book_ID.get() == "" or self.txt_student_id.get() == "":
            messagebox.showerror("Error !", "All Fields are Required !", parent=self.root)
        else:
            try:
                response = messagebox.askokcancel("checkout", "\nAre you sure?")
                if response:
                    self.current_book.book_check_out(self.txt_book_id.get(), self.txt_student_id.get())
                    messagebox.showinfo("Success !", "Done successfully !", parent=self.root)
            except Exception as es:
                messagebox.showerror("Error", f"Error due to : {str(es)}", parent=self.root)

    def book_create(self):
        if self.txt_book_title.get() == "" or self.txt_book_no_copies.get() == "" or self.txt_book_shelf_no.get() == "" or self.txt_book_id == "":
            messagebox.showerror("Error !", "All Fields are Required !", parent=self.root)
        else:
            try:
                self.current_book.set_book(self.txt_book_id.get(), self.txt_book_title.get(), self.txt_book_no_copies.get(),
                                           self.txt_book_shelf_no.get())

                my_data = self.current_book.check_book_in_db()

                if not my_data:

                    # Checking if student are sure about entries data...
                    response = messagebox.askokcancel("Book creation", "\nAre you sure?")

                    if response:

                        self.current_book.new_book()

                        messagebox.showinfo("Success !", "Creation Completed !", parent=self.root)
                        self.clear_data()

                    else:

                        # Aborting registration
                        self.clear_data()

                else:  # If data != []

                    # Error label because username is already on DB
                    messagebox.showerror("Error !", "Book already exist ! Try with another one.", parent=self.root)
            except Exception as es:
                messagebox.showerror("Error", f"Error due to : {str(es)}", parent=self.root)
