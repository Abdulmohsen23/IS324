from tkinter import *
from tkcalendar import *


class GUICalendar:
    def __init__(self, ws, text1, text2):
        ws.config(bg="#cd950c")

        hour_string = StringVar()
        min_string = StringVar()
        sec_hour = StringVar()
        last_value_sec = ""
        last_value = ""
        f = ('Times', 20)

        def display_msg_1():
            date = cal.get_date()
            m = min_sb.get()
            h = sec_hour.get()
            s = sec.get()
            t = f"{date} at {m}:{h}:{s}"
            text1.delete(0, END)
            text1.insert(0, t)
            self.msg_display_1.config(text=t)

        def display_msg_2():
            date = cal.get_date()
            m = min_sb.get()
            h = sec_hour.get()
            s = sec.get()
            t = f"{date} at {m}:{h}:{s}"
            text2.delete(0, END)
            text2.insert(0, t)
            self.msg_display_2.config(text=t)

        if last_value == "59" and min_string.get() == "0":
            hour_string.set(int(hour_string.get()) + 1 if hour_string.get() != "23" else 0)
            last_value = min_string.get()

        if last_value_sec == "59" and sec_hour.get() == "0":
            min_string.set(int(min_string.get()) + 1 if min_string.get() != "59" else 0)
        if last_value == "59":
            hour_string.set(int(hour_string.get()) + 1 if hour_string.get() != "23" else 0)
            last_value_sec = sec_hour.get()

        fone = Frame(ws)
        ftwo = Frame(ws)

        fone.grid(pady=1)
        ftwo.grid(pady=1)

        cal = Calendar(
            fone,
            selectmode="day",
            year=2023,
            month=6,
            day=5
        )
        cal.grid()

        min_sb = Spinbox(
            ftwo,
            from_=0,
            to=23,
            wrap=True,
            textvariable=hour_string,
            width=2,
            state="readonly",
            font=f,
            justify=CENTER
        )
        sec_hour = Spinbox(
            ftwo,
            from_=0,
            to=59,
            wrap=True,
            textvariable=min_string,
            font=f,
            width=2,
            justify=CENTER
        )

        sec = Spinbox(
            ftwo,
            from_=0,
            to=59,
            wrap=True,
            textvariable=sec_hour,
            width=2,
            font=f,
            justify=CENTER
        )

        min_sb.grid()
        sec_hour.grid()
        sec.grid()

        msg = Label(
            ws,
            text="Hour  Minute  Seconds",
            font=("Times", 12),
            bg="#cd950c"
        )
        msg.grid()

        action_button_1 = Button(
            ws,
            text="Borrow Start",
            padx=10,
            pady=1,
            command=display_msg_1
        )
        action_button_1.grid(pady=1)

        self.msg_display_1 = Label(
            ws,
            text="",
            bg="#cd950c"
        )
        self.msg_display_1.grid(pady=1)

        action_button_2 = Button(
            ws,
            text="Borrow End",
            padx=10,
            pady=1,
            command=display_msg_2
        )
        action_button_2.grid(pady=1)

        self.msg_display_2 = Label(
            ws,
            text="",
            bg="#cd950c"
        )
        self.msg_display_2.grid(pady=1)

        ws.mainloop()
